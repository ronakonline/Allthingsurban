<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();

	// Update version number
	$data = array('description' => '1.4');
	$this->db->where('type', 'version');
	$this->db->update('settings', $data);
?>
